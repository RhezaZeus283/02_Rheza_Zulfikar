import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# ==========================================
# SCRIPT KHUSUS MENAMPILKAN GRAFIK DARI EXCEL
# ==========================================

# 1. Load Data Excel yang sudah kamu buat
nama_file = "Dataset_Dummy_Power_Quality.xlsx"
print(f"Sedang membaca file {nama_file}...")

try:
    df = pd.read_excel(nama_file)
except FileNotFoundError:
    print("❌ File tidak ditemukan! Pastikan nama filenya benar.")
    exit()

# 2. Ambil 1 contoh data dari setiap jenis gangguan
# Filter kolom data saja (Time_0 sampai Time_99)
kolom_sinyal = [c for c in df.columns if "Time" in c]

# Ambil baris pertama yang labelnya 'Normal' (0)
data_normal = df[df['Label_Angka'] == 0].iloc[0][kolom_sinyal].values

# Ambil baris pertama yang labelnya 'Sag' (1)
data_sag = df[df['Label_Angka'] == 1].iloc[0][kolom_sinyal].values

# Ambil baris pertama yang labelnya 'Harmonic' (2)
data_harmonic = df[df['Label_Angka'] == 2].iloc[0][kolom_sinyal].values

# 3. Buat Plotting (Gambar Grafik)
plt.figure(figsize=(15, 5)) # Ukuran gambar (Lebar, Tinggi)

# Grafik 1: Normal
plt.subplot(1, 3, 1)
plt.plot(data_normal, color='blue', linewidth=2)
plt.title("Kelas Normal (Sinus Murni)")
plt.ylim(-2, 2)
plt.xlabel("Waktu (Sampel)")
plt.ylabel("Amplitudo Tegangan")
plt.grid(True, linestyle='--', alpha=0.6)

# Grafik 2: Sag
plt.subplot(1, 3, 2)
plt.plot(data_sag, color='orange', linewidth=2)
plt.title("Kelas Voltage Sag (Drop)")
plt.ylim(-2, 2)
plt.xlabel("Waktu (Sampel)")
plt.grid(True, linestyle='--', alpha=0.6)

# Grafik 3: Harmonic
plt.subplot(1, 3, 3)
plt.plot(data_harmonic, color='green', linewidth=2)
plt.title("Kelas Harmonics (Terdistorsi)")
plt.ylim(-2, 2)
plt.xlabel("Waktu (Sampel)")
plt.grid(True, linestyle='--', alpha=0.6)

# Tampilkan
plt.tight_layout()
print("Grafik muncul! Silakan Screenshot sekarang.")
plt.show()