import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt


nama_file = "Dataset_Dummy_Power_Quality.xlsx"
print(f"Sedang membaca file {nama_file}...")

try:
    df = pd.read_excel(nama_file)
except FileNotFoundError:
    print("❌ ERROR: File Excel tidak ditemukan! Jalankan 'buat_dataset.py' dulu.")
    exit()


X = df.drop(columns=['Label_Angka', 'Kategori_Gangguan']).values
y = df['Label_Angka'].values


SEQ_LENGTH = 100
X = X.reshape(X.shape[0], SEQ_LENGTH, 1)

print(f"Data berhasil dimuat. Dimensi Input: {X.shape}")


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = models.Sequential([
    layers.Conv1D(filters=32, kernel_size=3, activation='relu', input_shape=(SEQ_LENGTH, 1)),
    layers.MaxPooling1D(pool_size=2),
    layers.Conv1D(filters=64, kernel_size=3, activation='relu'),
    layers.MaxPooling1D(pool_size=2),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(3, activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])


print("\n--- Mulai Training ---")
history = model.fit(X_train, y_train, epochs=20, validation_data=(X_test, y_test))

# Tampilkan Grafik
plt.figure(figsize=(12, 5))

# Akurasi
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Latih')
plt.plot(history.history['val_accuracy'], label='Uji')
plt.title('Akurasi Model')
plt.legend()

# Confusion Matrix
y_pred = model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)
cm = confusion_matrix(y_test, y_pred_classes)

plt.subplot(1, 2, 2)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Normal', 'Sag', 'Harmonic'], yticklabels=['Normal', 'Sag', 'Harmonic'])
plt.title('Confusion Matrix')

plt.tight_layout()
plt.show()

print("\n--- Selesai ---")
print(classification_report(y_test, y_pred_classes, target_names=['Normal', 'Sag', 'Harmonic']))